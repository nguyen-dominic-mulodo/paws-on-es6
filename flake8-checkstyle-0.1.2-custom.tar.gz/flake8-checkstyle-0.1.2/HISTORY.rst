=======
History
=======

0.1.2 (2018-05-07)
------------------
* Support for flake8 --output-file argument

0.1.1 (2018-01-15)
------------------
* Modify release settings

0.1.0 (2018-01-15)
------------------
* Fixed some flake8 violations
* Introduced CircleCI
* Add status badge
* Release settings

0.0.1 (2018-01-08)
------------------

* First release on PyPI.
